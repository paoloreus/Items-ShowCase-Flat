<?php
include '../login/header.php';
include 'functions.php';
check_access();
echo "Welcome " . $_SESSION['username'];
echo "<br>";
echo "Please fill out the information required to change your password";
echo "<br> <br>"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password </title>
</head>
<body>
<form action="confirm.php" method="post">
    <label for="username">Username</label> <input type="text" name="username" placeholder="username" id="username">
    <br>
    <label for="password">Old Password</label> <input type="text" name="password" placeholder="old password" id="password">
    <br>
    <label for="password">New Password</label> <input type="text" name="newpassword" placeholder="new password" id="newpassword">
    <br> <br>
    <input type="submit" value="Submit Changes">

    <br> <br>
</form>


</main></body><!-- /.container -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>
