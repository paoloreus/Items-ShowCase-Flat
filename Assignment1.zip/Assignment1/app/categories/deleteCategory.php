<?php
if(isset($_GET['act'])) {
    $cag = file('../../app/categories/categories.csv');
    $id = $_GET['id'];
    foreach ($cag as $index => $cg) {
        $fields = explode(',', $cg);

        if ($fields[0] == $id) {
            unset($cag[$index]);
            echo "<h1>Category Deleted</h1>";
            break;
        }
    }
    file_put_contents('../../app/categories/categories.csv', implode('', $cag));
    //header('../../app/login/adminView.php');
    echo "<br>";
    echo "<a href='../login/adminView.php'> Back to Homepage </a>";


}

else {
    echo "not deleted";
}