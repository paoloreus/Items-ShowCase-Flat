<?php
include '../login/functions.php';
check_access();
?>
<h1>Add Category</h1>

<form action="../categories/doAdd.php" method="post">
    Title: <input type="text" name="title"> <br>
    Description: <input type="text" name="description"> <br>
    <input type="hidden" name="id"> <br>
    <input type="submit">


</form>
