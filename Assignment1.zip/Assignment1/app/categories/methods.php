<?php
function getCategories(){
    $file=fopen('../categories/categories.csv','rb');
    $categories = array();

    while(!feof($file)){

        $category =fgetcsv($file);

        if($category===false) {
            continue;
        }

        $categories[]=$category;
    }
    echo "Categories are here";
    return $categories;
}