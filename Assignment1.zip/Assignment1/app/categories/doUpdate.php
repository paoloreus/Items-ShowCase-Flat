<?php
$id = $_REQUEST['id'];
$updated_cag = $id . ',' . $_REQUEST['title'] . ',' .$_REQUEST['description'] . PHP_EOL;
$cag = file('../../app/categories/categories.csv');

foreach($cag as $index => $cg){
$fields = explode(',' , $cg);
if($fields[0] == $id){
$cag[$index] = $updated_cag;
break;
}
}

file_put_contents('../../app/categories/categories.csv' , implode('', $cag));
echo "<br>";
echo "<a href='../login/adminView.php'> Back to Homepage </a>";