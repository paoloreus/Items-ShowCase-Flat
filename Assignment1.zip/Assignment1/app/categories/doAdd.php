<?php
$cag = file('../../app/categories/categories.csv');
$id = count($cag) + 1;
$new_cag = $id . ',' . $_REQUEST['title'] . ',' . $_REQUEST['description'] . PHP_EOL;
$cag[$id] = $new_cag;
$fields = implode(',' , $cag);

file_put_contents('../../app/categories/categories.csv' , implode('', $cag));
echo "<br>";
echo "<a href='../login/adminView.php'> Back to Homepage </a>";