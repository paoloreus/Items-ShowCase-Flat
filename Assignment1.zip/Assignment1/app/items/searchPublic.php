<?php
echo "<table class='table table-hover'>";
$text_c = array();
$text = $_REQUEST['search'];

$info = file('../../app/items/products.csv');
for($i = 0; $i < count($info); $i++){
    $fields = explode(',' , $info[$i]);
    echo '<tr>';
    for($x = 0; $x < count($fields); $x++){
        if(strpos($fields[1], $text) !== false){
            if($x == 0){
                echo '<td><img src="' . '../items/' . $fields[4] . '"> . </td>';
            }
            else if($x != 0 && $x != 4){
                echo '<td>' . $fields[$x] . '</td>';
            }

        }

    }


}
echo "</table>";