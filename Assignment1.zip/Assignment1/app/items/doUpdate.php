<?php
$id = $_REQUEST['id'];
$updated_item = $id . ',' . $_REQUEST['title'] . ',' .$_REQUEST['description'] . ','
    . $_REQUEST['price'] . ',' . $_REQUEST['upload'] . ',' . $_REQUEST['category'] . PHP_EOL;
$items = file('../../app/items/products.csv');

foreach($items as $index => $item){
    $fields = explode(',' , $item);
    if($fields[0] == $id){
        $items[$index] = $updated_item;
        break;
    }
}

file_put_contents('../../app/items/products.csv' , implode('', $items));
echo "<br>";
echo "<a href='../login/adminView.php'> Back to Homepage </a>";