<?php
    include '../login/functions.php';
    $items = file('../../app/items/products.csv');
    $id = $_REQUEST['id'];
    $item_to_update = '';

    foreach($items as $index => $item){
        $fields = explode(',', $item);
        if($fields[0] == $id){
            $item_to_update = $fields;
        }
    }

    if(is_array($item_to_update)) { ?>
        <form action="../items/doUpdate.php?id=<?php echo $id?>" method="post">
        <h1>Update Item</h1>
        Title: <input type="text" name="title" value="<?php echo $item_to_update[1]; ?>">
        Description: <input type="text" name="description" value="<?php echo $item_to_update[2]; ?>"><br>
        Price in cents: <input type="text" name="price" value="<?php echo $item_to_update[3]; ?>"><br>
        Upload Image: <input type='file' name='upload' id='upload' <img src="<?php echo $item_to_update[4]?>"> <br>
        <?php print_categories(); ?> <br>

        <input type="submit">


    <?php } ?>
    </form>

    <?php if(is_array($item_to_update) == false) { ?>
        <h1>Cannot find the item</h1>
    <?php }
