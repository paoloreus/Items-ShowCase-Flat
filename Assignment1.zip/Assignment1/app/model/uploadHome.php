<?php
include '../login/functions.php';
check_access();
?>
<!DOCTYPE html>
<html>
<body>
<form action="upload.php" method="post" enctype="multipart/form-data">
    Upload Image
    <input type="file" name="upload" id="upload">
    <input type="submit" value="Upload" name="submit">

</form>

</body>

</html>