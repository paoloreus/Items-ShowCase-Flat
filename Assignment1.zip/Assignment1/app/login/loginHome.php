<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Log In</title>
</head>
<body>
<form action="login.php" method="post">
    <?php $user_info = explode(':', file('../../../../protected/pass.txt')[0]);?>
    <label for="username">Username</label> <input type="text" name="username" value="<?php echo $user_info[0]; ?>" id="username">
    <br>
    <label for="password">Password</label> <input type="text" name="password" value="mypassword" id="password">
    <br> <br>
    <input type="submit" value="Login">

    <br> <br>

</form>

</body>

</html>