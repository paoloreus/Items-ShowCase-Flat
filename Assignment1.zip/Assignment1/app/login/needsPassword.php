<?php
session_start();
echo "Welcome " . $_SESSION['username'];
echo "<br> <br>";
?>
<a href="logout.php">Log Out</a>
<br>
<a href="changePassword.php">Change Password</a>
<br>
<a href="adminView.php">Admin View Page</a>