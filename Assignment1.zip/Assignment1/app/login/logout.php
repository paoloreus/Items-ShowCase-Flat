<?php
session_start();
session_destroy();
echo "Redirecting ...";
sleep(3);
header('Location: ../../public/index.php');
exit();
?>